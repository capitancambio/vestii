from time import sleep
from myo import init, Hub, DeviceListener

class Listener(DeviceListener):

    def on_pair(self, myo, timestamp, firmware_version):
        print("List Output for Myo!")

    def on_unpair(self, myo, timestamp):
        print("Goodbye, Myo!")

    def on_orientation_data(self, myo, timestamp, quat):
		Xvalue = quat.x
		Yvalue = quat.y
		Zvalue = quat.z 
		Weight = quat.w
		
		print ("\nOutput from your Armband:")
		print("\nX-Value is:")
		print (quat.x)
				
		
       # print("Orientation:", quat.x, quat.y, quat.z, quat.w)

init("../../myo-sdk-win-0.9.0/bin")
hub = Hub()
hub.run(1000, Listener())
try:
    while True:
        sleep(0.5)
except KeyboardInterrupt:
    print('\nQuit')
finally:
    hub.shutdown()  # !! crucial