Myo API (:mod:`myo`)
====================

.. autofunction:: myo.init

.. autoclass:: myo.Hub
  :members:
  :undoc-members:

.. autoclass:: myo.DeviceListener
  :members:
  :undoc-members:

.. autoclass:: myo.Feed
  :members:
  :undoc-members:
