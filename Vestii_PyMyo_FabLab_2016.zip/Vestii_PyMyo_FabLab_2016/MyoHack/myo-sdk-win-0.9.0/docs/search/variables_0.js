var searchData=
[
  ['firmwareversionhardwarerev',['firmwareVersionHardwareRev',['../structmyo_1_1_firmware_version.html#ad614949077766a987d0ea23cbb72df13',1,'myo::FirmwareVersion']]],
  ['firmwareversionmajor',['firmwareVersionMajor',['../structmyo_1_1_firmware_version.html#aa1889f298258591db6765ab634c1a86b',1,'myo::FirmwareVersion']]],
  ['firmwareversionminor',['firmwareVersionMinor',['../structmyo_1_1_firmware_version.html#a5f2359273a5c9c60931f2a30dd436b79',1,'myo::FirmwareVersion']]],
  ['firmwareversionpatch',['firmwareVersionPatch',['../structmyo_1_1_firmware_version.html#a5b3fb7fcb68a74a07f90f6d1dbaedde8',1,'myo::FirmwareVersion']]]
];
