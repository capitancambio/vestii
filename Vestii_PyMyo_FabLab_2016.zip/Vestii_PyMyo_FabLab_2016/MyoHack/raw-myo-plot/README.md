# raw-myo-plot
Raw Myo Plot grabs the raw data streams from a Thalmic Myo and displays them in real-time.

Myo data is acquired using [myo-python](https://github.com/NiklasRosenstein/myo-python).

Matplotlib is awesome, but I had better luck using [PyQtGraph](http://www.pyqtgraph.org/) for real-time displays.

![Screenshot](/myo-display.png)
